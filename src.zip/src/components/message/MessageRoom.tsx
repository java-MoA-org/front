import './MessageRoom.css';
import defaultProfile from '../../assets/images/default-profile.png';
import { useEffect, useState, useRef, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { useCookies } from 'react-cookie';
import useChatSocket from '../../hooks/useChatSocket';
import axios from 'axios';
import { getUserInfoByIdRequest, getUserProfileImageByIdRequest, getUserNicknameByIdRequest } from '../../apis';

// interface: 메시지 데이터 타입 정의
interface Message {
  senderId: string;
  receiverId: string;
  content: string;
  imageUrl?: string;
  type: 'TEXT' | 'IMAGE' | 'DELETE' | 'READ';
  timestamp: string;
  isRead?: boolean;
  isDeleted?: boolean;
}

const MessageRoom = () => {
  // URL 파라미터에서 userId, partnerId 추출
  const { userId, partnerId } = useParams();
  // 쿠키에서 accessToken 추출
  const [cookies] = useCookies(['accessToken']);
  const accessToken = cookies['accessToken'];

  // state: 메시지 목록 상태
  const [messages, setMessages] = useState<Message[]>([]);
  const [hasUnreadSent, setHasUnreadSent] = useState(false);
  // state: 입력창 값 상태
  const [input, setInput] = useState('');
  // state: 상대방 프로필 이미지 상태
  const [partnerProfileImage, setPartnerProfileImage] = useState<string>(defaultProfile);
  // state: 상대방 닉네임 상태
  const [partnerNickname, setPartnerNickname] = useState('');
  // state: 삭제 옵션 표시할 메시지 인덱스 상태
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  // state: 채팅박스 DOM 참조 (스크롤 제어용)
  const chatBoxRef = useRef<HTMLDivElement>(null);

  // function: 메시지 옵션(삭제 등) 토글 함수
  const toggleOptions = (index: number) => {
    setActiveIndex((prev) => (prev === index ? null : index));
  };

  // function: 메시지 삭제 처리 함수
  const handleDelete = async (index: number) => {
    const deletedMessage = messages[index];
    if (!deletedMessage) return;

    // 1. 로컬에서 삭제
    setMessages((prev) => prev.filter((_, i) => i !== index));
    setActiveIndex(null); // 옵션 닫기

    try {
      await axios.post(
        '/api/message/hide',
        {
          messageNumber: index,
        },
        {
          headers: { Authorization: `Bearer ${accessToken}` },
        }
      );
    } catch (err) {
      console.error('메시지 숨기기 실패:', err);
    }

    // 2. WebSocket으로 삭제 메시지 전송
    const deleteNotice: Message = {
      senderId: userId!,
      receiverId: partnerId!,
      content: deletedMessage.timestamp, // 삭제 대상 메시지의 timestamp를 기준으로 삭제
      imageUrl: '',
      type: 'DELETE', // DELETE 타입으로 전송
      timestamp: new Date().toISOString(),
    };

    sendMessage(deleteNotice);
  };

  // 메시지 수신 처리 함수 (useCallback으로 메모이제이션)
  const onMessageReceived = useCallback((msg: Message) => {
    if (msg.type === 'DELETE') {
      setMessages((prev) =>
        prev.map((m) =>
          m.timestamp === msg.content
            ? {
                ...m,
                type: 'TEXT',
                content: '상대가 메시지를 삭제했습니다.',
                isDeleted: true,
              }
            : m
        )
      );
    } else if (msg.type === 'READ') {
      console.log('[👁️ READ 수신 - isRead 업데이트 시도]', msg);
      setMessages((prev) =>
        prev.map((m) =>
          m.senderId === partnerId && !m.isRead
            ? { ...m, isRead: true }
            : m
        )
      );
    } else {
      setMessages((prev) => [...prev, msg]);
    }
  }, [partnerId]);

  // socket: WebSocket 연결 및 메시지 수신 처리
  const { sendMessage } = useChatSocket(userId!, onMessageReceived);

  // effect: 컴포넌트 마운트 시 초기 메시지 로딩 및 상대방 프로필 조회
  useEffect(() => {
    if (!userId || !partnerId || !accessToken) return;

    // 과거 메시지 API 호출
    axios
      .get(`/api/message/${userId}/${partnerId}`, {
        headers: { Authorization: `Bearer ${accessToken}` },
      })
      .then((res) => {
        setMessages(res.data); // 메시지 상태 세팅
      })
      .catch((err) => {
        console.error('메시지 불러오기 실패:', err);
      });

    // 상대방 프로필 이미지 요청
    getUserProfileImageByIdRequest(partnerId!, accessToken)
      .then((url) => {
        setPartnerProfileImage(url || defaultProfile);
      })
      .catch(() => {
        setPartnerProfileImage(defaultProfile);
      });

    // 상대방 닉네임 요청
    getUserNicknameByIdRequest(partnerId!, accessToken)
      .then((nickname) => setPartnerNickname(nickname))
      .catch(() => setPartnerNickname('알 수 없음'));
  }, [userId, partnerId, accessToken]);

  // effect: 외부 클릭 시 메시지 옵션 메뉴 닫기 처리
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.message-options')) {
        setActiveIndex(null);
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, []);

  // effect: 메시지룸 접속 시 콘솔 출력 (디버깅용)
  useEffect(() => {
    console.log('[📡 메시지룸 접속]', userId, partnerId);
  }, []);

  // effect: 메시지 목록 변경 시 자동 스크롤 처리 및 읽음 처리 API 호출
  useEffect(() => {
    if (chatBoxRef.current) {
      chatBoxRef.current.scrollTop = chatBoxRef.current.scrollHeight;
    }
    // 메시지 읽음 처리 API 호출
    if (userId && partnerId && accessToken) {
      axios
        .post(
          '/api/message/read',
          {
            userId,
            partnerId,
          },
          {
            headers: { Authorization: `Bearer ${accessToken}` },
          }
        )
        .catch((err) => {
          console.error('읽음 처리 실패:', err);
        });
    }
  }, [messages]);

  // function: 메시지 전송 처리 함수
  const handleSend = () => {
    if (!input.trim()) return; // 빈 메시지 전송 방지

    const newMsg: Message = {
      senderId: userId!,
      receiverId: partnerId!,
      content: input,
      imageUrl: '',
      type: 'TEXT',
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, newMsg]); // 클라이언트에서 즉시 메시지 추가
    sendMessage(newMsg); // WebSocket으로 서버 전송
    setInput(''); // 입력창 초기화
  };

  // function: 입력창에서 Enter 키 입력 시 메시지 전송
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  // render: 메시지룸 컴포넌트 렌더링
  return (
    <div className="message-room">
      {/* 헤더 - 상대 프로필 이미지 및 닉네임 표시 */}
      <div className="header">
        <img src={partnerProfileImage} alt="상대 프로필" width={40} height={40} />
        <span>{partnerNickname}</span>
      </div>

      {/* 채팅 메시지 목록 영역 */}
      <div className="chat-box" ref={chatBoxRef}>
        {messages.map((msg, i) => {
          const isMine = msg.senderId === userId; // 내가 보낸 메시지 여부

          return (
            <div key={i} className={`message-container ${isMine ? 'mine' : 'theirs'}`}>
              {!isMine && <img className="profile-icon" src={partnerProfileImage} alt="상대 프로필" />}
              <div className={isMine ? 'my-message' : 'their-message'}>
                {msg.isDeleted ? (
                  <p className="deleted-text">상대가 메시지를 삭제했습니다.</p>
                ) : (
                  <>
                    {msg.type === 'TEXT' && <p>{msg.content}</p>}
                    {msg.type === 'IMAGE' && <img src={msg.imageUrl} alt="image" />}
                  </>
                )}
                <div className="message-timestamp">
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  {isMine && msg.isRead && (
                    <span className="read-icon">[읽음]</span>
                  )}
                </div>
                <div className="message-options">
                  <span className="dots" onClick={() => toggleOptions(i)}>
                    ⋯
                  </span>
                  {activeIndex === i && (
                    <div className="dropdown-menu message-delete-menu">
                      <button onClick={() => handleDelete(i)}>삭제</button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* 메시지 입력창 및 전송 버튼 */}
      <div className="input-area">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="메시지를 입력하세요"
        />
        <button onClick={handleSend}>전송</button>
      </div>
    </div>
  );
};

export default MessageRoom;
