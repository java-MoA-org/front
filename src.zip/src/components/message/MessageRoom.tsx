import React, { useEffect, useState, useRef } from 'react';
import { useParams } from 'react-router-dom';
import SockJS from 'sockjs-client';
import { Client } from '@stomp/stompjs';
import useSignInUserStore from '../../stores/sign-in-user.store';
import { getUserInfoByIdRequest } from '../../apis';
import { useCookies } from 'react-cookie';
import MessageInput from './MessageInput';
import defaultProfile from '../../assets/images/default-profile.png';

interface Message {
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
}

const MessageRoom = () => {
  const { partnerId } = useParams<{ partnerId: string }>();
  const { userId } = useSignInUserStore();
  const [cookies] = useCookies();
  const accessToken = cookies.ACCESS_TOKEN;

  const [messages, setMessages] = useState<Message[]>([]);
  const [partnerInfo, setPartnerInfo] = useState<any>(null);
  const stompClient = useRef<Client | null>(null);

  useEffect(() => {
    if (!partnerId || !accessToken) return;
    getUserInfoByIdRequest(partnerId, accessToken)
      .then((res) => setPartnerInfo(res))
      .catch(() => setPartnerInfo(null));
  }, [partnerId, accessToken]);

  useEffect(() => {
    if (!userId || !partnerId) return;

    const socket = new SockJS('http://localhost:4000/ws');
    const client = new Client({
      webSocketFactory: () => socket,
      reconnectDelay: 5000,
      onConnect: () => {
        console.log('STOMP 연결됨');
        client.subscribe(`/user/${userId}/queue/messages`, (message) => {
          const body = JSON.parse(message.body);
          if (
            (body.senderId === partnerId && body.receiverId === userId) ||
            (body.senderId === userId && body.receiverId === partnerId)
          ) {
            setMessages((prev) => [...prev, body]);
          }
        });
      },
    });

    client.activate();
    stompClient.current = client;

    return () => {
      client.deactivate();
    };
  }, [userId, partnerId]);

  const sendMessage = (content: string) => {
    if (!partnerId || !stompClient.current?.connected) return;

    const message = {
      senderId: userId,
      receiverId: partnerId,
      content,
    };

    stompClient.current.publish({
      destination: '/app/send',
      body: JSON.stringify(message),
    });

    setMessages((prev) => [
      ...prev,
      {
        ...message,
        timestamp: new Date().toISOString(),
      },
    ]);
  };

  return (
    <div className="message-room">
      <div className="room-header">
        <img
          src={partnerInfo?.userProfileImage || defaultProfile}
          alt="상대 프로필"
          className="profile-img"
        />
        <strong>{partnerInfo?.userNickname || partnerId}</strong>
      </div>

      <div className="message-list">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`message-item ${msg.senderId === userId ? 'sent' : 'received'}`}
          >
            <div className="message-content">{msg.content}</div>
            <div className="timestamp">{msg.timestamp}</div>
          </div>
        ))}
      </div>

      <MessageInput onSend={sendMessage} />
    </div>
  );
};

export default MessageRoom;