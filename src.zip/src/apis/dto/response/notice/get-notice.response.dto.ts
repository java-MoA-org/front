interface GetNoticeResponseDto {
    title: string;
    content: string;
    views: number;
    creationDate: string;
  }
  export default GetNoticeResponseDto;