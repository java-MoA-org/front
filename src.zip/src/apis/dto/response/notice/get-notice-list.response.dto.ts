interface NoticeSummary {
    title: string;
    creationDate: string;
    views: number;
  }
  
  interface GetNoticeListResponseDto {
    noticeList: NoticeSummary[];
  }
  
  export default GetNoticeListResponseDto;