import { useEffect, useState } from "react";
import "./style.css";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { Board, Daily, Trade } from "../../../types/interfaces";
import { MY_USER_PATH } from "../../../constants";
import { getUserPageRequest } from "../../../apis";
import ResponseDto from "../../../apis/dto/response/response.dto";
import GetUserPageResponseDto from "../../../apis/dto/response/userpage/get-user-page.response.dto";
import { usePagination } from "../../../hooks";

export default function UserBoard() {
  const [searchParams] = useSearchParams();
  const typeParam = searchParams.get("type");
  const { nickname } = useParams();

  const navigator = useNavigate();

  const [boards, setBoards] = useState<Board[]>([]);
  const [dailys, setDailys] = useState<Daily[]>([]);
  const [trades, setTrades] = useState<Trade[]>([]);

  const boardPagination = usePagination<Board>();
  const dailyPagination = usePagination<Daily>();
  const tradePagination = usePagination<Trade>();

  const [activeTab, setActiveTab] = useState<"board" | "daily" | "used">(
    typeParam === "board" ? "board" : typeParam === "daily" ? "daily" : "used"
  );

  // function: get user page response 처리 함수 //
  const getUserBoardResponse = (responseBody: GetUserPageResponseDto | ResponseDto | null) => {
    const message = !responseBody
      ? "서버에 문제가 있습니다."
      : responseBody.code === "DBE"
      ? "서버에 문제가 있습니다."
      : responseBody.code === "AF"
      ? "인증에 실패했습니다."
      : "";

    const isSuccess = responseBody !== null && responseBody.code === "SU";
    if (!isSuccess) {
      alert(message);
      return;
    }

    const { boards, dailyBoards, tradeBoards } = responseBody as GetUserPageResponseDto;
    setBoards(boards);
    setDailys(dailyBoards);
    setTrades(tradeBoards);
  };

  // effect: 컴포넌트 로드시 실행할 함수 //
  useEffect(() => {
    if (!nickname) {
      navigator(MY_USER_PATH); // 경로 없음 → 리디렉션
      return;
    }

    getUserPageRequest(nickname)
      .then(getUserBoardResponse)
      .catch(() => alert("서버 요청 중 오류가 발생했습니다."));
  }, [nickname]);

  // effect: 컴포넌트 로드시 실행할 함수 //
  useEffect(() => {
    if (typeParam === "board" || typeParam === "daily" || typeParam === "used") {
      setActiveTab(typeParam);
    }
  }, [typeParam]);

  useEffect(() => {
    boardPagination.setTotalList([...boards].reverse());
  }, [boards]);

  useEffect(() => {
    dailyPagination.setTotalList([...dailys].reverse());
  }, [dailys]);

  useEffect(() => {
    tradePagination.setTotalList([...trades].reverse());
  }, [trades]);

  // variable: board,daily,user 변수 //
  const boardClass = activeTab === "board" ? "board active" : "board";
  const dailyClass = activeTab === "daily" ? "daily active" : "daily";
  const usedClass = activeTab === "used" ? "used active" : "used";

  return (
    <div id="my-user-board">
      <div className="board-type">
        <div className={boardClass} onClick={() => setActiveTab("board")}>
          익명 게시판
        </div>
        <div className={dailyClass} onClick={() => setActiveTab("daily")}>
          일상 게시판
        </div>
        <div className={usedClass} onClick={() => setActiveTab("used")}>
          중고거래 게시판
        </div>
      </div>
      <div className="board-container">
        <div className="board-name">
          <div className="board-numbers">게시물 번호</div>
          <div className="board-titles">제목</div>
          <div className="board-views">조회수</div>
          <div className="board-likes">좋아요 수</div>
          <div className="board-date-time">날짜</div>
        </div>
        {activeTab === "board" &&
          (boards.length === 0 ? (
            <div className="no-content">아직 작성한 글이 없습니다.</div>
          ) : (
            boardPagination.viewList.map(
              ({ boardSequence, title, views, likeCount, creationDate }) => (
                <div className="board-content" key={boardSequence}>
                  <div className="board-numbers content">{boardSequence}</div>
                  <div className="board-titles content">{title}</div>
                  <div className="board-views content">{views}</div>
                  <div className="board-likes content">{likeCount}</div>
                  <div className="board-date-time content">{creationDate}</div>
                </div>
              )
            )
          ))}
        {activeTab === "daily" &&
          (dailys.length === 0 ? (
            <div className="no-content">아직 작성한 글이 없습니다.</div>
          ) : (
            dailyPagination.viewList.map(
              ({ dailySequence, title, views, likeCount, creationDate }) => (
                <div className="board-content" key={dailySequence}>
                  <div className="board-numbers content">{dailySequence}</div>
                  <div className="board-titles content">{title}</div>
                  <div className="board-views content">{views}</div>
                  <div className="board-likes content">{likeCount}</div>
                  <div className="board-date-time content">{creationDate}</div>
                </div>
              )
            )
          ))}

        {activeTab === "used" &&
          (trades.length === 0 ? (
            <div className="no-content">아직 작성한 글이 없습니다.</div>
          ) : (
            tradePagination.viewList.map(
              ({ tradeSequence, title, views, likeCount, creationDate }) => (
                <div className="board-content" key={tradeSequence}>
                  <div className="board-numbers content">{tradeSequence}</div>
                  <div className="board-titles content">{title}</div>
                  <div className="board-views content">{views}</div>
                  <div className="board-likes content">{likeCount}</div>
                  <div className="board-date-time content">{creationDate}</div>
                </div>
              )
            )
          ))}
        <div className="pagination">
          {(activeTab === "board"
            ? boardPagination.pageList
            : activeTab === "daily"
            ? dailyPagination.pageList
            : tradePagination.pageList
          ).map((page) => (
            <button
              key={page}
              className={
                page ===
                (activeTab === "board"
                  ? boardPagination.currentPage
                  : activeTab === "daily"
                  ? dailyPagination.currentPage
                  : tradePagination.currentPage)
                  ? "active"
                  : ""
              }
              onClick={() => {
                if (activeTab === "board") boardPagination.setCurrentPage(page);
                else if (activeTab === "daily") dailyPagination.setCurrentPage(page);
                else tradePagination.setCurrentPage(page);
              }}
            >
              {page}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
