import './NoticeUpdate.css';
import { useEffect, useState, useRef } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import { Editor } from '@toast-ui/react-editor';
import '@toast-ui/editor/dist/toastui-editor.css';

const NoticeUpdate = () => {
  const { noticeId } = useParams<{ noticeId: string }>();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const editorRef = useRef<Editor>(null);
  const navigate = useNavigate();

  // 공지사항 불러오기
  useEffect(() => {
    if (!noticeId) return;

    axios
      .get(`/api/v1/notice/${noticeId}`)
      .then((res) => {
        setTitle(res.data.title);
        setContent(res.data.content);
      })
      .catch((err) => {
        console.error('❌ 공지 불러오기 실패:', err);
        alert('공지사항을 불러오지 못했습니다.');
        navigate('/notice');
      });
  }, [noticeId, navigate]);

  // 공지사항 수정 요청
  const handleUpdate = async () => {
    const accessToken = localStorage.getItem('accessToken');
    if (!accessToken) {
      alert('로그인이 필요합니다.');
      return;
    }

    const editedContent = editorRef.current?.getInstance().getHTML();

    try {
      await axios.put(
        `/api/v1/notice/update/${noticeId}`,
        { title, content: editedContent },
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
      alert('공지 수정 완료');
      navigate('/notice');
    } catch (e) {
      alert('수정 실패');
      console.error('❌ 수정 실패:', e);
    }
  };

  return (
    <div className="notice-update-wrapper">
      <div className="notice-update-container">
        <h2 className="notice-update-title">공지사항 수정</h2>
        <input
          className="notice-update-input"
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="제목을 입력해주세요"
        />
        <Editor
          ref={editorRef}
          initialValue={content}
          previewStyle="vertical"
          height="400px"
          initialEditType="wysiwyg"
          useCommandShortcut={true}
          key={content} // 에디터 초기화
        />
        <button className="notice-update-button" onClick={handleUpdate}>
          수정 완료
        </button>
      </div>
    </div>
  );
};

export default NoticeUpdate;